﻿namespace Epik_PersonApp.Common
{
    public class ResponseAPI<T> : ResponseGeneric<T>
    {
    }
}
