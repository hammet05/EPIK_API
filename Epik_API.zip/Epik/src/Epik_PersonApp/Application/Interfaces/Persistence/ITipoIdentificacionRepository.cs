﻿using Epik_PersonApp.Domain.Entities;

namespace Epik_PersonApp.Application.Interfaces.Persistence
{
    public interface ITipoIdentificacionRepository : IRepository<TipoIdentificacion>
    {
    }
}
